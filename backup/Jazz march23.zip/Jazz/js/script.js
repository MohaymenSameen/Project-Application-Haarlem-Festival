function required()
{
    var empt = document.forms["tick"]["quantity"].value;
    var field = document.forms["tick"]["date"].value;
    if(empt == "")
    {
        alert("Please choose amount");
        return false;
    }
    else if(field == "Select Date")
    {
        alert("Please select a date ");
        return false;
    }
    else
    {
        return true;
    }    
} 
