<?php
    require_once ('../model/jazz_model.php');
    class JazzController extends JazzModel
    {       
        public function recieveData()
        {            
            $row = $this->getData();            
            return $row;
        }
        public function recieveTimetables($date)
        {
            $row = $this->getTimetables();               
            foreach($row as $res)
            {
                if($res['date'] == $date)
                {                    
                    echo "<tr><td>"
                    .$res['location']."</td><td>"
                    .$res['timing']."</td><td>"
                    .$res['band']."</td><td>"
                    ,"&euro;".$res['price']."</td></tr>";
                }                
            }
            return $row;
        }     
        public function recieveDate($date)
        {            
            $row = $this->getTimetables();
            foreach($row as $res)
            {
                if($res['date'] == $date)
                {                    
                    $date1 = $res['date'];
                    $newDate = date("l, F d", strtotime($date1));
                    echo '<h2>'.$newDate.'</h2>';         
                    break;           
                }
            }
            return $newDate;
        } 
        public function recievePrice($ticket,$date)
        {
            $row = $this->getTimetables();   
                      
            foreach($row as $res)
            {
                if($res['band'] == $ticket && $res['date'] == $date)
                {
                    $price = $res['price'];                                        
                }                              
            }            
            return $price;
        }  
    }
?>