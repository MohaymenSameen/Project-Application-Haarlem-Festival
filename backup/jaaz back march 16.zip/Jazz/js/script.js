function selectTickets()
