<?php
    require_once ('../model/jazz_model.php');
    class JazzController extends JazzModel
    {  
        public function recieveData()
        {            
            $row = $this->getData();            
            return $row;
        }
        public function recieveTimetables($date)
        {
            $row = $this->getTimetables();               
            foreach($row as $res)
            {
                if($res['date'] == $date)
                {
                    echo "<tr><td>"
                    .$res['location']."</td><td>"
                    .$res['timing']."</td><td>"
                    .$res['band']."</td><td>"
                    ,"&euro;".$res['price']."</td></tr>";
                }                
            }
            return $row;
        }     
        public function recieveDate($date)
        {            
            $row = $this->getTimetables();
            foreach($row as $res)
            {
                if($res['date'] == $date)
                {
                    $date1 = $res['date'];
                    echo '<h2>'.$date1.'</h2>';         
                    break;           
                }
            }
            return $date1;
        }   
        public function recieveBand($date)   
        {
            $recieveData = $this->getTimetables();
            $recieveDate = $this->recieveDate($date);
            
            foreach($recieveData as $res)
            {
                if($recieveDate == $date)
                {
                    $band = $res['band'];
                    echo '<option>'.$band.'</option>';                    
                }
            }
            return $band;
        }
    }
?>