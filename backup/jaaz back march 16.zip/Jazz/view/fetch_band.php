<?php
//fetch.php

 $connect = mysqli_connect("localhost", "root", "", "hfitteam6_enhaarlemfestival");
 $output = '';

  $query = "SELECT band FROM jazz_timetable WHERE date = '".$_POST["date"]."' GROUP BY band";
  $result = mysqli_query($connect, $query);
  $output = '<option value="">Select band</option>';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '<option value="'.$row["band"].'">'.$row["band"].'</option>';
  }
 

 echo $output;

?>