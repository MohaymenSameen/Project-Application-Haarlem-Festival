<?php
    require_once ('../model/jazz_model.php');
    class JazzController extends JazzModel
    {       
        public function recieveData()
        {            
            $row = $this->getData();            
            return $row;
        }
        public function recieveTimetables($date)
        {
            $row = $this->getTimetables();               
            foreach($row as $res)
            {
                if($res['date'] == $date)
                {                    
                    echo "<tr><td>"
                    .$res['location']."</td><td>"
                    .$res['timing']."</td><td>"
                    .$res['band']."</td><td>"
                    ,"&euro;".$res['price']."</td></tr>";
                }                
            }
            return $row;
        }     
        public function recieveDate($date)
        {            
            $row = $this->getTimetables();
            foreach($row as $res)
            {
                if($res['date'] == $date)
                {                    
                    $date1 = $res['date'];
                    $newDate = date("l, F d", strtotime($date1));
                    echo '<h2>'.$newDate.'</h2>';         
                    break;           
                }
            }
            return $newDate;
        } 
        public function recieveTicket($band,$date)
        {
            $row = $this->getTimetables();            
            foreach($row as $res)
            {
                if($res["band"] == $band && $res["date"] == $date)
                {                                  
                    $tickets = array("item_id"=>$res['id'],"item_name"=>$res['band'],"item_date"=>$res['date'],"item_price"=>$res['price'],"item_quantity"=>$_POST["quantity"]);                                                                     
                }
            }
            return $tickets;
        }             
        public function shoppingCart($band,$date)
        {
            $tickets = $this->recieveTicket($band,$date);

            if(isset($_SESSION['shopping_cart']))
            {            
                $count = count($_SESSION['shopping_cart']);
                $item_array=$tickets;	
                $_SESSION['shopping_cart'][$count] = $item_array;                
            }
            else
            {
                $item_array = $tickets;	
                $_SESSION['shopping_cart'][0] = $item_array;                  
            }
            return $_SESSION['shopping_cart'];
        }
        public function displayShoppingCart()
        {
            if(!empty($_SESSION['shopping_cart']))
            {
                $total=0;
                echo '<h2 id="recent">Recently Added Items</h2>';
                echo '<hr>';
                foreach($_SESSION['shopping_cart'] as $keys => $values)
                {
                    $newDate = date("l, F d", strtotime($values["item_date"]));
                    echo '<h2 id="quantity">'.$values["item_name"].'</h2>';
                    echo '<h2 id="band">'.'<strong>',"Date: ",'</strong>',$newDate.'</h2>';                                
                    echo '<h2 id="band">'.'<strong>',"Price: ",'</strong>',"&euro;",$values["item_price"].'</h2>';
                    echo '<h2 id="band">'.'<strong>',"Quantity: ",'</strong>',$values["item_quantity"],"x".'</h2>';
                    $total += $values["item_quantity"]*$values["item_price"];
                   // echo '<input type="hidden" name="delete" value="add"/>';
                   // echo '<button type="submit" class="delete">X</button>';
                    echo "<a href=jazz_view.php?action=delete&id=".$values["item_id"].">Remove</a>";
                    echo '<hr>';                                
                }
                echo '<h2>'."Total Price: ","&euro;",$total.'</h2>';                            
            }           
        }
        public function removeFromCart()
        {
            if(isset($_GET["action"]))
            {
                if($_GET["action"] == "delete")
                {                   
                    foreach($_SESSION['shopping_cart'] as $keys => $values)
                    {
                        if($values["item_id"] == $_GET["id"])
                        {
                            unset($_SESSION['shopping_cart'][$keys]); 
                            header("Location: jazz_view.php");
                        }
                    }
                }                
            }
            if(empty($_SESSION['shopping_cart']))
            {
                echo '<h2>'."Shopping Cart Is Empty".'</h2>';
            }            
        }        
    }
?>